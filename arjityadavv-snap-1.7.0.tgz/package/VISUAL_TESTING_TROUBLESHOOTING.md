# Visual Testing Troubleshooting Guide

## Common Issues and Solutions

### 1. Visual Testing Directories Not Created

**Symptoms:**
- No `visual-baselines`, `visual-actual`, or `visual-diffs` folders created
- Error messages about directory creation failures
- Visual testing fails silently

**Causes & Solutions:**

#### A. Permission Issues
```bash
# Problem: Permission denied in current directory
# Solution: Run with proper permissions or specify different directory
snap run -t test.json --visual-dir ./my-visual-tests

# Or use a directory you have write access to
snap run -t test.json --visual-dir ~/visual-tests
```

#### B. Global Installation Issues
```bash
# Problem: Package installed globally, directories created in wrong location
# Solution: Always specify visual directory explicitly
snap run -t test.json --visual-dir $(pwd)/visual-tests

# Or create a dedicated directory
mkdir visual-tests
snap run -t test.json --visual-dir ./visual-tests
```

#### C. Current Working Directory Issues
```bash
# Problem: Running from system directory or read-only location
# Solution: Change to project directory first
cd /path/to/your/project
snap run -t test.json

# Or specify absolute paths
snap run -t /full/path/test.json --visual-dir /full/path/visual-tests
```

### 2. Debugging Visual Testing Issues

#### Enable Debug Mode
The framework now includes comprehensive logging. Look for these messages:

```
🔍 Visual Testing Configuration:
   Base Directory: /your/project/path
   Baselines: /your/project/path/visual-baselines
   Actual: /your/project/path/visual-actual
   Diffs: /your/project/path/visual-diffs

📁 Creating visual testing directories...
   ✓ Baselines: /path/to/visual-baselines
   ✓ Actual screenshots: /path/to/visual-actual
   ✓ Visual diffs: /path/to/visual-diffs
✅ Visual testing directories initialized successfully
```

#### Fallback Directory
If main directory creation fails, the framework automatically tries:
```
🔄 Trying fallback directory: /home/user/.snap-visual-testing
```

### 3. Directory Structure Verification

After running tests, you should see:
```
your-project/
├── visual-baselines/           # Baseline images
│   ├── test_ui_navigate_0_url_abc123.png
│   └── test_ui_click_0_el_button.png
├── visual-actual/              # Current test screenshots  
│   ├── test_ui_navigate_0_url_abc123_timestamp.png
│   └── test_ui_click_0_el_button_timestamp.png
└── visual-diffs/               # Difference images (if any)
    └── test_ui_navigate_0_url_abc123_diff_timestamp.png
```

### 4. Configuration Options

#### Method 1: CLI Options
```bash
# Specify custom visual testing directory
snap run -t test.json --visual-dir ./custom-visual-dir

# Use absolute path
snap run -t test.json --visual-dir /full/path/to/visual-tests
```

#### Method 2: Environment Variables
```bash
# Set visual testing path via environment
export SNAP_VISUAL_DIR=/path/to/visual-tests
snap run -t test.json
```

#### Method 3: Configuration File
Add to your test script JSON:
```json
{
  "testifact_info": {
    "testsuite_name": "My Tests",
    "visual_testing_path": "./custom-visual-dir"
  }
}
```

### 5. Common Error Messages & Fixes

#### "Permission denied creating Baselines directory"
```bash
# Fix: Use directory with write permissions
snap run -t test.json --visual-dir ~/my-tests/visual

# Or change permissions (Linux/Mac)
chmod 755 ./visual-baselines
```

#### "Path exists but is not a directory"
```bash
# Fix: Remove conflicting file
rm ./visual-baselines  # If it's a file
snap run -t test.json
```

#### "Could not initialize directories"
```bash
# Fix: Check disk space and permissions
df -h  # Check disk space
ls -la  # Check permissions
snap run -t test.json --visual-dir ~/temp/visual-tests
```

### 6. Verifying Installation

Test visual testing functionality:

```bash
# Create test directory
mkdir test-visual-setup
cd test-visual-setup

# Create minimal test
cat > test.json << 'EOF'
{
  "testifact_info": {
    "testsuite_name": "Visual Test Setup",
    "testsuite_owner": "Test User",
    "test_report_path": "./reports"
  },
  "testifact_items": [{
    "test_name": "Basic Visual Test",
    "description": "Test visual testing setup",
    "execute": "yes",
    "test_actions": [{
      "action_type": "ui",
      "action_name": "ui_open_browser",
      "action_config": {"browser_name": "chrome"},
      "action_parameters": {"visual_check": "yes"}
    }]
  }]
}
EOF

# Run test
snap run -t test.json --headless

# Verify directories created
ls -la
# Should show: visual-baselines/, visual-actual/, visual-diffs/
```

### 7. Advanced Troubleshooting

#### Check Package Installation
```bash
# Verify package is installed
npm list -g @arjityadavv/snap-automator

# Check command availability
which snap
snap --version
```

#### Manual Directory Creation
```bash
# If automatic creation fails, create manually
mkdir -p visual-baselines visual-actual visual-diffs
chmod 755 visual-baselines visual-actual visual-diffs

# Then run tests
snap run -t test.json
```

#### File System Issues
```bash
# Check available disk space
df -h

# Check inode usage (Linux/Mac)
df -i

# Check file permissions
ls -la visual-*
```

### 8. Platform-Specific Issues

#### Windows
- Use forward slashes in paths: `--visual-dir ./visual-tests`
- Avoid spaces in directory names
- Run PowerShell/Command Prompt as Administrator if needed

#### macOS
- Check Gatekeeper restrictions
- Ensure Xcode command line tools installed: `xcode-select --install`

#### Linux
- Check SELinux policies if applicable
- Ensure proper file permissions: `chmod 755`

### 9. Getting Help

If issues persist:

1. **Enable verbose logging** (coming in next version)
2. **Check system requirements**: Node.js 14+, npm 6+
3. **Verify Playwright installation**: `npx playwright install`
4. **Create issue** with full error logs and system info

### 10. Success Indicators

Visual testing is working correctly when you see:

```
🔍 Visual Testing Configuration:
   Base Directory: /your/path
   ...
✅ Visual testing directories initialized successfully
📸 Screenshot taken: test_action_0_timestamp.png
✨ Created new baseline: test_action_0.png
```

And directories are created with appropriate files in each.