# InstantAutomator Distribution Guide

## Method 1: NPM Registry (Recommended)

### Publishing to NPM Registry

1. **Login to NPM:**
   ```bash
   npm login
   ```

2. **Publish the package:**
   ```bash
   npm publish --access public
   ```

3. **Users install globally:**
   ```bash
   npm install -g @arjityadavv/snap-automator
   ```

4. **Use anywhere:**
   ```bash
   snap-test run -t my-test.json
   # OR
   snap-automator run -t my-test.json
   ```

### Version Updates
```bash
npm version patch    # 1.5.0 -> 1.5.1
npm version minor    # 1.5.0 -> 1.6.0
npm version major    # 1.5.0 -> 2.0.0
npm publish
```

---

## Method 2: Private NPM Registry

### Using GitHub Packages
1. **Update package.json:**
   ```json
   {
     "name": "@arjityadavv/instant-automator",
     "publishConfig": {
       "registry": "https://npm.pkg.github.com"
     }
   }
   ```

2. **Publish:**
   ```bash
   npm publish
   ```

3. **Users install:**
   ```bash
   npm install -g @arjityadavv/snap-automator --registry=https://npm.pkg.github.com
   ```

---

## Method 3: Single Executable (Advanced)

### Using PKG to create standalone executable

1. **Install pkg:**
   ```bash
   npm install -g pkg
   ```

2. **Add to package.json:**
   ```json
   {
     "pkg": {
       "scripts": ["src/**/*.js", "schemas/**/*.json"],
       "assets": ["schemas/**/*", "src/**/*"],
       "targets": ["node18-win-x64", "node18-macos-x64", "node18-linux-x64"]
     }
   }
   ```

3. **Build executables:**
   ```bash
   pkg . --out-path dist/
   ```

4. **Creates:**
   - `dist/instant-automator-win.exe`
   - `dist/instant-automator-macos`
   - `dist/instant-automator-linux`

---

## Method 4: Tarball Distribution

### Create distributable tarball

1. **Pack the application:**
   ```bash
   npm pack
   ```

2. **Creates:** `arjityadavv-instant-automator-1.5.0.tgz`

3. **Users install from tarball:**
   ```bash
   npm install -g arjityadavv-instant-automator-1.5.0.tgz
   ```

---

## Method 5: Docker Container

### Dockerfile for containerized distribution

1. **Create Dockerfile:**
   ```dockerfile
   FROM node:18-alpine
   
   # Install dependencies
   RUN apk add --no-cache \
       chromium \
       firefox
   
   # Set environment variables
   ENV PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1
   ENV PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium-browser
   
   # Create app directory
   WORKDIR /app
   
   # Copy package files
   COPY package*.json ./
   RUN npm ci --only=production
   
   # Copy source code
   COPY . .
   
   # Create global link
   RUN npm link
   
   # Set entry point
   ENTRYPOINT ["snap"]
   CMD ["--help"]
   ```

2. **Build and distribute:**
   ```bash
   docker build -t instant-automator .
   docker run -v $(pwd):/workspace instant-automator run -t /workspace/test.json
   ```

---

## Installation Examples

### Global NPM Installation (Recommended)
```bash
# Install
npm install -g @arjityadavv/instant-automator

# Use anywhere
cd /any/project
snap run -t my-tests.json

# Update
npm update -g @arjityadavv/instant-automator

# Uninstall
npm uninstall -g @arjityadavv/instant-automator
```

### Local Project Installation
```bash
# In existing project
npm install @arjityadavv/instant-automator

# Use with npx
npx snap run -t tests.json

# Or via npm scripts in package.json
{
  "scripts": {
    "test": "snap run -t tests/main.json"
  }
}
```

## Benefits of Each Method

| Method | Pros | Cons | Best For |
|--------|------|------|----------|
| **NPM Registry** | Easy updates, global access, standard | Requires NPM account | Public distribution |
| **GitHub Packages** | Private, integrated with GitHub | Requires auth setup | Private teams |
| **Single Executable** | No Node.js needed, standalone | Large files, no auto-updates | Offline environments |
| **Tarball** | Simple, no registry needed | Manual updates | Internal distribution |
| **Docker** | Isolated, consistent environment | Requires Docker | CI/CD, containers |

## Recommended Workflow

1. **Development:** Use local installation
2. **Testing:** Use tarball or local registry
3. **Production:** Use NPM registry for easy distribution
4. **Enterprise:** Use private registry or executables